//
//  ContactViewModel.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//

class ContactViewModel {
    var allContacts: [Contact] = [
        Contact(firstName: "Nethra", lastName: "K", phone: "1234567890", isFavourite: true),
        Contact(firstName: "Surya", phone: "1234567890"),
        Contact(firstName: "Sree", lastName: "Y", phone: "1234567890"),
        Contact(firstName: "Dharshana", lastName: "I", phone: "1234567890"),
        Contact(firstName: "Swa", lastName: "L", phone: "1234567890"),
        Contact(firstName: "Nethra", lastName: "K", phone: "1234567890", isFavourite: true),
        Contact(firstName: "Surya", phone: "1234567890"),
        Contact(firstName: "Sree", lastName: "Y", phone: "1234567890"),
        Contact(firstName: "Dharshana", lastName: "I", phone: "1234567890"),
        Contact(firstName: "Swa", lastName: "L", phone: "1234567890"),
        Contact(firstName: "Nethra", lastName: "K", phone: "1234567890"),
        Contact(firstName: "Surya", phone: "1234567890"),
        Contact(firstName: "Sree", lastName: "Y", phone: "1234567890"),
        Contact(firstName: "Dharshana", lastName: "I", phone: "1234567890"),
        Contact(firstName: "Swathi", lastName: "L", phone: "1234567890")
    ]
    
    func addContact(firstName: String, lastName: String? = nil, phone: String, email: String? = nil, isFavourite: Bool = false){
        let contact = Contact(
            firstName: firstName,
            lastName: lastName,
            phone: phone,
            email: email,
            isFavourite: isFavourite
        )
        
        allContacts.append(contact)
    }
    
    func deleteContact(contact: Contact){
        let id = contact.id
        allContacts.removeAll(where: { $0.id == id })
    }
    
    func toggleFavourite(for contact: Contact) {
        if let index = allContacts.firstIndex(where: { $0.id == contact.id }) {
            allContacts[index].isFavourite.toggle()
        }
    }
    
    
}
