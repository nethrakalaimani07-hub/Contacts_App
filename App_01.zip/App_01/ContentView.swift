//
//  ContentView.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        NavigationStack {
            TabView {
                
                Tab("All", systemImage: "person.fill") {
                    ContactsView()
                }
                
                Tab("Favourites", systemImage: "heart.fill",
                    content: { FavouritesView() })
                
                
            }
            .tabBarMinimizeBehavior(.never)
        }
        
    }
    
}

#Preview {
    ContentView()
}



// Deprecated :
/*
TabView {
    ContactsView()
        .tabItem {
            Label("Contacts", systemImage: "person")
        }
    
    FavouritesView()
        .tabItem{
            Label("Favourites", systemImage: "heart.fill")
        }
}
*/
