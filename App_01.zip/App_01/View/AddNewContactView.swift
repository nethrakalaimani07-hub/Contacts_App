//
//  AddNewContactView.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//


import SwiftUI

struct AddNewContactView: View {
    
    var body: some View {
        
    }
    
}


#Preview {
    AddNewContactView()
}
