//
//  FavouritesView.swift
//  Contacts
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import SwiftUI

struct FavouritesView: View {
    
    var body: some View {
        Text("Favourites")
            .navigationTitle("Favourites")
    }
    
}

#Preview {
    FavouritesView()
}
