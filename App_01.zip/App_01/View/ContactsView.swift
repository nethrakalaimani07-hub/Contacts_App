//
//  ContactsView.swift
//  Contacts
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import SwiftUI

struct ContactsView: View {
    
    @State private var viewModel = ContactViewModel()
    
    var body: some View {
        List {
            ForEach(viewModel.allContacts) { item in
                
                HStack {
                    VStack(alignment: .leading) {
                        Text("\(item.firstName) \(item.lastName ?? "")")
                            .font(.headline)
                        Text(item.phone)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    if item.isFavourite {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                    }
                }
            }
        }
        .navigationTitle("Contacts")
    }
}


#Preview {
    ContactsView()
}

