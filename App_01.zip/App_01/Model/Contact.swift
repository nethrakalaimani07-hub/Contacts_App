//
//  Person.swift
//  Contacts
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import Foundation

struct Contact: Identifiable, Comparable {
    let id: UUID = UUID()
    var firstName: String
    var lastName: String?
    var phone: String
    var email: String?
    var isFavourite: Bool = false
    
    static func < (rhs: Contact, lhs: Contact) -> Bool {
        return rhs.firstName < lhs.firstName
    }
}
