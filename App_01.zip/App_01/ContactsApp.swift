//
//  App_01App.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import SwiftUI

@main
struct ContactsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
