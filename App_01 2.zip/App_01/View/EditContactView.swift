//
//  EditContactView.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import SwiftUI

struct EditContactView: View {

    let contact: Contact
    @Environment(ContactViewModel.self) private var viewModel

    @State private var firstName = ""
    @State private var lastName = ""
    @State private var phone = ""
    @State private var email = ""

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        Form {
            Section("Name") {
                TextField("First Name", text: $firstName)
                TextField("Last Name (optional)", text: $lastName)
            }

            Section("Contact Info") {
                TextField("Phone", text: $phone)
                    .keyboardType(.phonePad)
                TextField("Email (optional)", text: $email)
                    .keyboardType(.emailAddress)
            }
        }
        .navigationTitle("Edit Contact")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button(role: .cancel) {
                    dismiss()
                }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Save") {
                    saveChanges()
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.hidden)
        .onAppear {
            firstName = contact.firstName
            lastName = contact.lastName ?? ""
            phone = contact.phone
            email = contact.email ?? ""
        }
    }

    private func saveChanges() {
        var updatedContact = contact
        updatedContact.firstName = firstName
        updatedContact.lastName = lastName.isEmpty ? nil : lastName
        updatedContact.phone = phone
        updatedContact.email = email.isEmpty ? nil : email

        viewModel.updateContact(updatedContact)
        dismiss()
    }
}

