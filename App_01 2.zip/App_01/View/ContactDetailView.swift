//
//  ContactDetailView.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import SwiftUI

struct ContactDetailView: View {

    let contactID: UUID
    @Environment(ContactViewModel.self) private var viewModel


    @State private var showingEdit = false
    @State private var showingDeleteConfirm = false
    @Environment(\.dismiss) private var dismiss

    private var contact: Contact? {
        viewModel.contacts.first { $0.id == contactID }
    }

    var body: some View {
        VStack {
            if let contact {
                List {
                    Section {
                        VStack(spacing: 0) {
                            VStack(spacing: 8) {
                                Image(systemName: "person.crop.circle.fill")
                                    .resizable()
                                    .frame(width: 80, height: 80)
                                    .scaledToFit()
                                
                                Text(contact.fullName)
                                    .font(.title2)
                                    .bold()
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            
                            Divider().padding()
                            
                            // Action buttons
                            HStack(spacing: 32) {
                                ContactActionButton(
                                    icon: "message.fill", title: "Message"
                                ) {
                                    // send message function
                                }
                                
                                ContactActionButton(
                                    icon: "phone.fill", title: "Call"
                                ) {
                                    // call function
                                }
                                
                                ContactActionButton(
                                    icon: "video.fill", title: "Video"
                                ) {
                                    // video call function
                                }
                                
                                ContactActionButton(
                                    icon: "envelope.fill", title: "Mail"
                                ) {
                                    // send email
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                        }
                    }
                    
                    Section("Contact Info") {
                        LabeledContent("Phone", value: contact.phone)
                        
                        if let email = contact.email, !email.isEmpty {
                            LabeledContent("Email", value: email)
                        }
                    }
                    
                    Section {
                        Button {
                            viewModel.toggleFavourite(contact)
                        } label: {
                            Label(
                                contact.isFavourite ? "Remove from Favourites" : "Add to Favourites",
                                systemImage: contact.isFavourite ? "star.slash" : "star"
                            )
                        }
                        
                        Button(role: .destructive) {
                            showingDeleteConfirm = true
                        } label: {
                            Label("Delete Contact", systemImage: "trash")
                        }
                    }
                }
                .navigationTitle(contact.fullName)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Edit") {
                            showingEdit = true
                        }
                    }
                }
                .sheet(isPresented: $showingEdit) {
                    NavigationStack {
                        EditContactView(contact: contact)
                    }
                }
                .alert("Delete \(contact.fullName)?", isPresented: $showingDeleteConfirm) {
                    Button("Delete", role: .destructive) {
                        viewModel.deleteContact(contact)
                        dismiss()
                    }
                    Button("Cancel", role: .cancel) {}
                }
            }
        }
    }
}

private struct ContactActionButton: View {
    let icon: String
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 20))
                    .foregroundColor(.white)
                    .frame(width: 50, height: 50)
                    .background(Color.blue)
                    .clipShape(Circle())

                Text(title)
                    .font(.caption)
                    .foregroundColor(.blue)
            }
        }
    }
}

#Preview {
    NavigationStack {
        let viewModel = ContactViewModel()
        ContactDetailView(contactID: viewModel.contacts[0].id)
    }
}
