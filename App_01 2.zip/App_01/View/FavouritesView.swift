//
//  FavouritesView.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import SwiftUI

struct FavouritesView: View {

    @Environment(ContactViewModel.self) private var viewModel
    
    var body: some View {
        
        let groups = viewModel.groupedContacts(from: viewModel.favouriteContacts)
        let letters = viewModel.sectionLetters(for: groups)
        
        List {
            ForEach(letters, id: \.self) { letter in
                FavouriteSectionRows(
                    letter: letter,
                    contacts: groups[letter] ?? [],
                    viewModel: viewModel
                )
            }
        }
        .navigationTitle("Favourites")
        .navigationBarTitleDisplayMode(.inline)
        .overlay {
            if viewModel.favouriteContacts.isEmpty {
                ContentUnavailableView(
                    "No Favourites",
                    systemImage: "star",
                    description: Text("Mark a contact as favourite to see it here.")
                )
            }
        }
    }
}

private struct FavouriteSectionRows: View {
    
    let letter: String
    let contacts: [Contact]
    @Environment(ContactViewModel.self) private var viewModel
    
    
    var body: some View {
        Section(header: Text(letter)) {
            ForEach(contacts) { contact in
                FavouriteRow(contact: contact)
//                    .listRowSeparatorTint(.cyan.opacity(0.3))
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) {
                            viewModel.deleteContact(contact)
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }
//                    .listRowBackground(Color.blue.opacity(0.15))
            }
            
        }
        
    }
}

private struct FavouriteRow: View {
    let contact: Contact
    @Environment(ContactViewModel.self) private var viewModel

    var body: some View {
        NavigationLink {
            ContactDetailView(contactID: contact.id)
        } label: {
            HStack {
                VStack(alignment: .leading) {
                    Text(contact.fullName)
                        .font(.headline)
                    Text(contact.phone)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }

                Spacer()

                Image(systemName: "star.fill")
                    .foregroundColor(.yellow)

//              Action is left empty for now.
                Button {
                    // start call
                } label: {
                    Image(systemName: "phone.fill")
                        .foregroundColor(.white)
                        .padding(8)
                        .background(Color.green)
                        .clipShape(Circle())
                }
            }
            
        }
    }
}

#Preview {
    NavigationStack {
        FavouritesView()
    }
}
