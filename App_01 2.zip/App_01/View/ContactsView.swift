//
//  ContactsView.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import SwiftUI

struct ContactsView: View {
    
    @Environment(ContactViewModel.self) private var viewModel: ContactViewModel
    
    @State private var showingAddContact = false
    
    var body: some View {
        let groups = viewModel.groupedContacts(from: viewModel.contacts)
        let letters = viewModel.sectionLetters(for: groups)
        
        List {
            ForEach(letters, id: \.self) { letter in
                ContactSectionRows(
                    letter: letter,
                    contacts: groups[letter] ?? [],
                    viewModel: viewModel
                )
            }
        }
        .navigationTitle("Contacts")
        .navigationBarTitleDisplayMode(.inline)
        .overlay {
            if viewModel.contacts.isEmpty {
                ContentUnavailableView(
                    "No Contacts",
                    systemImage: "person.crop.circle.badge.plus",
                    description: Text("Tap + to add your first contact.")
                )
            }
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showingAddContact = true
                } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .fullScreenCover(isPresented: $showingAddContact) {
            NavigationStack {
                AddNewContactView()
            }
        }
    }
    
}

private struct ContactSectionRows: View {
    let letter: String
    let contacts: [Contact]
    let viewModel: ContactViewModel

    var body: some View {
        Section(header: Text(letter)) {
            ForEach(contacts) { contact in
                ContactRow(contact: contact, viewModel: viewModel)
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) {
                            viewModel.deleteContact(contact)
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }
            }
        }
    }
}

private struct ContactRow: View {
    let contact: Contact
    let viewModel: ContactViewModel

    var body: some View {
        NavigationLink {
            ContactDetailView(contactID: contact.id, viewModel: viewModel)
        } label: {
            HStack {
                VStack(alignment: .leading) {
                    Text(contact.fullName)
                        .font(.headline)
                    Text(contact.phone)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }

                Spacer()

                if contact.isFavourite {
                    Image(systemName: "star.fill")
                        .foregroundColor(.yellow)
                }

                Button {
                    // call function
                } label: {
                    Image(systemName: "phone.fill")
                        .foregroundColor(.white)
                        .padding(8)
                        .background(Color.green)
                        .clipShape(Circle())
                }
            }
        }
    }
}

#Preview {
    NavigationStack {
        ContactsView(viewModel: ContactViewModel())
    }
}
