//
//  AddNewContactView.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import SwiftUI

struct AddNewContactView: View {

    @State private var firstName = ""
    @State private var lastName = ""
    @State private var phone = ""
    @State private var email = ""
    @State private var isFavourite = false
    
    @Environment(ContactViewModel.self) private var viewModel

    @Environment(\.dismiss) private var dismiss

    private var canSave: Bool {
        !firstName.trimmingCharacters(in: .whitespaces).isEmpty &&
        !phone.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var body: some View {
        Form {
            Section("Name") {
                TextField("First Name", text: $firstName)
                TextField("Last Name (optional)", text: $lastName)
            }

            Section("Contact Info") {
                TextField("Phone", text: $phone)
                    .keyboardType(.phonePad)
                TextField("Email (optional)", text: $email)
                    .keyboardType(.emailAddress)
            }

            Section {
                Toggle("Mark as Favourite", isOn: $isFavourite)
                    .tint(.purple)
            }
        }
        .navigationTitle("New Contact")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button(role: .cancel) { dismiss() }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Save") { save() }
                    .disabled(!canSave)
            }
        }
    }

    private func save() {
        viewModel.addContact(
            firstName: firstName.trimmingCharacters(in: .whitespaces),
            lastName: lastName.trimmingCharacters(in: .whitespaces).isEmpty ? nil : lastName,
            phone: phone.trimmingCharacters(in: .whitespaces),
            email: email.trimmingCharacters(in: .whitespaces).isEmpty ? nil : email,
            isFavourite: isFavourite
        )
        dismiss()
    }
}

#Preview {
    NavigationStack {
        AddNewContactView()
    }
}
