//
//  Contact.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//

import Foundation


struct Contact: Identifiable {
    let id: UUID = UUID()
    var firstName: String
    var lastName: String?
    var phone: String
    var email: String?
    var isFavourite: Bool = false

    // Computed property
    // First Last or just First if there is no Last name
    var fullName: String {
        if let lastName {
            if(!lastName.isEmpty) {
                return "\(firstName) \(lastName)"
            }
        }
        return firstName
    }
}

