//
//  ContactViewModel.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//
//   Views never touch `contacts` directly — they always go through a method here.
//
//  @Observable (not the old ObservableObject/@StateObject) is
//  what lets SwiftUI notice when `contacts` changes and redraw
//  only the views that actually read it.
//

import Foundation
import Observation

@Observable
class ContactViewModel {

    // The contacts list in the whole app
    var contacts: [Contact] = [
        Contact(firstName: "Nethra", lastName: "K", phone: "1234567890", isFavourite: true),
        Contact(firstName: "Surya", phone: "1234567890"),
        Contact(firstName: "Sree", lastName: "Y", phone: "1234567890"),
        Contact(firstName: "Dharshana", lastName: "I", phone: "1234567890"),
        Contact(firstName: "Swathi", lastName: "L", phone: "1234567890", isFavourite: true),
        Contact(firstName: "Arun", lastName: "P", phone: "9876543210"),
        Contact(firstName: "Bala", lastName: "M", phone: "9988776655"),
        Contact(firstName: "Nishanth", lastName: "S A", phone: "9898776655", isFavourite: true)

    ]

    func addContact(firstName: String, lastName: String?, phone: String, email: String?, isFavourite: Bool) {
        let newContact = Contact(
            firstName: firstName,
            lastName: lastName,
            phone: phone,
            email: email,
            isFavourite: isFavourite
        )
        contacts.append(newContact)
    }

    func updateContact(_ contact: Contact) {
        guard let index = contacts.firstIndex(where: { $0.id == contact.id })
              else { return }
        contacts[index] = contact
    }

    func deleteContact(_ contact: Contact) {
        contacts.removeAll { $0.id == contact.id }
    }

    func toggleFavourite(_ contact: Contact) {
        guard let index = contacts.firstIndex(where: { $0.id == contact.id })
                else { return }
        contacts[index].isFavourite.toggle()
    }


    // Contacts marked as favourite — used by FavouritesView.
    var favouriteContacts: [Contact] {
        contacts.filter { $0.isFavourite }
    }

    func groupedContacts(from contacts: [Contact]) -> [String: [Contact]] {
        var groups: [String: [Contact]] = [:]

        for contact in contacts {
            let firstLetter = String(contact.firstName.prefix(1)).uppercased()
            groups[firstLetter, default: []].append(contact)
        }

        for letter in groups.keys {
            groups[letter] = sortByFirstName(groups[letter] ?? [])
        }

        return groups
    }

    func sectionLetters(for groups: [String: [Contact]]) -> [String] {
        groups.keys.sorted()
    }

    private func sortByFirstName(_ contacts: [Contact]) -> [Contact] {
        return contacts.sorted { first, second in
            return first.firstName < second.firstName
        }
    }
}
