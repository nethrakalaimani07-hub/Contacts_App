//
//  ContentView.swift
//  App_01
//
//  Created by Nethra Kalaimani on 23/10/26.
//
//
import SwiftUI

struct ContentView: View {

    @Environment(ContactViewModel.self) private var viewModel: ContactViewModel

    var body: some View {

        TabView {
            
            Tab("All", systemImage: "person.fill") {
                NavigationStack {
                    ContactsView()
                }
            }
            
            Tab("Favourites", systemImage: "heart.fill") {
                NavigationStack {
                    FavouritesView()
                }
            }
        }
        .tabBarMinimizeBehavior(.never)
    }
}

//
//struct ContentView: View {
//    let viewModel: ContactViewModel
//    @State private var selectedTab: Int = 0
//
//    var body: some View {
//        TabView(selection: $selectedTab) {
//
//            Tab("All", systemImage: "person.fill", value: 1) {
//                NavigationStack {
//                    ContactsView(viewModel: viewModel)
//                }
//            }
//
//            Tab("Favourites", systemImage: "heart.fill", value: 0) {
//                NavigationStack {
//                    FavouritesView(viewModel: viewModel)
//                }
//            }
//        }
//        .tabBarMinimizeBehavior(.never)
//    }
//}

#Preview {
    ContentView()
}
// Deprecated :
/*
TabView {
    ContactsView()
        .tabItem {
            Label("Contacts", systemImage: "person")
        }
    
    FavouritesView()
        .tabItem{
            Label("Favourites", systemImage: "heart.fill")
        }
}
*/
